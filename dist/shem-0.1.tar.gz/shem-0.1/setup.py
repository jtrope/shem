from distutils.core import setup

setup(
    name = 'shem',
    version = '0.1',
    py_modules = ['shem'],
    author = "jtrope",
    author_email = "jonathan@jonathantrope.com",
    description = "A fake data generator"
)
