class hello:
  def greet(self):
    print "hello"
